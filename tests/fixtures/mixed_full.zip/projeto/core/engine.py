def run(): print('ok')
