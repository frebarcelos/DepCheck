from projeto.core import run
