print('deep')
