print('main')
