print('first')
