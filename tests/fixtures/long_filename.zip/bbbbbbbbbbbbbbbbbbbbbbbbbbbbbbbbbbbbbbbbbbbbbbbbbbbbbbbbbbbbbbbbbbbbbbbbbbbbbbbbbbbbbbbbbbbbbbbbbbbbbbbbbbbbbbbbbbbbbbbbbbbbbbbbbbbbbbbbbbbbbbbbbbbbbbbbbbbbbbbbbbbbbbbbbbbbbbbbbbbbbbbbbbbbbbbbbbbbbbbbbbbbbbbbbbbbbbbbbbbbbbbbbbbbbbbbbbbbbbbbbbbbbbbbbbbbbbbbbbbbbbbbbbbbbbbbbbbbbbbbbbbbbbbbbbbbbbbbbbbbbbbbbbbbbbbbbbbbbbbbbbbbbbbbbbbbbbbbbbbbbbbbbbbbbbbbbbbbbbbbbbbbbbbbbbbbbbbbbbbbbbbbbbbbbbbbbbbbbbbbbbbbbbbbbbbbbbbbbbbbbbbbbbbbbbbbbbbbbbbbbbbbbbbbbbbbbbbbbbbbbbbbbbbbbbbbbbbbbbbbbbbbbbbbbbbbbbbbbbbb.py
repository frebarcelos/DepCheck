print('very long')
