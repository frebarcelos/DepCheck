print('spaces')
