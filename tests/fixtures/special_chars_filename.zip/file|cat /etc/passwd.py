print('pipe injection')
