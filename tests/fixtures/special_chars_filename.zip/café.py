print('unicode')
