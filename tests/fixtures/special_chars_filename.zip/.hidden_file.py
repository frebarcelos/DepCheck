print('dot file')
