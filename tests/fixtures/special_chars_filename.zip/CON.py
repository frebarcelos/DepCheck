print('reserved Windows name')
