print('command substitution')
