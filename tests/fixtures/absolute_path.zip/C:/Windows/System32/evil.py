print('evil')
