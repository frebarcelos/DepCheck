print('relative traversal')
