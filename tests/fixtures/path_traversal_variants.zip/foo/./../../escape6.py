print('dot in middle')
