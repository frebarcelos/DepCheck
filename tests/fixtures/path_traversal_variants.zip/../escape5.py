print('dot-slash traversal')
