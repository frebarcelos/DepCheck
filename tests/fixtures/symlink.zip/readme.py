print('legit')
